
# Keymono Web

Tienda online básica hecha en HTML, CSS y JS.

## Cómo subir a GitHub + Netlify

1. Subí estos archivos a un nuevo repositorio de GitHub.
2. Entrá a https://netlify.com y conectá tu cuenta de GitHub.
3. Elegí el repo y publicá. ¡Listo!

## Cómo editar el alias de pago
1. Abrí el archivo `index.html`
2. Buscá la línea: `<code id="alias">pone tu alias</code>`
3. Reemplazá "pone tu alias" por tu alias de MercadoPago real.

## Créditos
Diseño base generado para Keymono con tecnología web estática (sin backend).
